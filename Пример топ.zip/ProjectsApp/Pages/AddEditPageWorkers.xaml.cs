﻿using Microsoft.Win32;
using ProjectsApp.Classes;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace ProjectsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPageWorkers.xaml
    /// </summary>
    public partial class AddEditPageWorkers : Page
    {
        private Workers _currentItem = new Workers();
        string imgLoc = "пусто";
        public AddEditPageWorkers(Workers selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
                Titletxt.Text = "Изменение сотрудника";
                BtnAdd.Content = "Изменить";
            }
            DataContext = _currentItem;
            CMBWorkersPosition.ItemsSource = ProjectBDEntities.GetContext().Positions.ToList();
            CMBWorkersPosition.SelectedValuePath = "idPost";
            CMBWorkersPosition.DisplayMemberPath = "Title";
        }

        private void ImageLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog { Filter = "Файлы изображений (*.png, *.jpg, *.jpeg, *.bmp)|*.png;*.jpg;*.jpeg;*.bmp|Все файлы (*.*)|*.*", Title = "Выберите фото сотрудника" };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    imageWorker.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void ImageClear_Click(object sender, RoutedEventArgs e)
        {
            imageWorker.Source = (ImageSource)imageWorker.FindResource("UnknownWorker");
            imgLoc = "очистить";
        }


        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Surname))) error.AppendLine("Укажите фамилию сотрудника.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Name))) error.AppendLine("Укажите имя сотрудника.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Patronymic))) error.AppendLine("Укажите отчество сотрудника.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Email))) error.AppendLine("Укажите Email сотрудника.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.Phone))) error.AppendLine("Укажите телефон сотрудника.");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentItem.idPost))) error.AppendLine("Укажите должность сотрудника.");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (imgLoc != "пусто" && imgLoc != "очистить")
            {
                FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                _currentItem.Photo = br.ReadBytes((int)fs.Length);
            }
            if (imgLoc == "очистить") _currentItem.Photo = null;
            if (_currentItem.idWorker == 0)
            {
                ProjectBDEntities.GetContext().Workers.Add(_currentItem);
                try
                {
                    ProjectBDEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageWorkers());
                    MessageBox.Show("Новый сотрудник успешно добавлен!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
            else
            {
                try
                {
                    ProjectBDEntities.GetContext().SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageWorkers());
                    MessageBox.Show("Сотрудник успешно изменён!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageWorkers());
        }
    }
}