﻿using ProjectsApp.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageTasks.xaml
    /// </summary>
    public partial class PageTasks : Page
    {
        public PageTasks()
        {
            InitializeComponent();
            dtgTasks.ItemsSource = ProjectBDEntities.GetContext().Tasks.ToList();
            txtCountRows.Text = dtgTasks.Items.Count.ToString();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (SearchPanel.Visibility == Visibility.Hidden)
            {
                SearchMargin.Height = new GridLength(0.8, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                SearchMargin.Height = new GridLength(0, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void txbTitle_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgTasks.ItemsSource != null) dtgTasks.ItemsSource = ProjectBDEntities.GetContext().Tasks.Where(x => x.Title.ToLower().Contains(txbTitle.Text.ToLower())).ToList();
            if (txbTitle.Text.Count() == 0) dtgTasks.ItemsSource = ProjectBDEntities.GetContext().Tasks.ToList();
            txtCountRows.Text = dtgTasks.Items.Count.ToString();
        }

        private void MenuAddItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageTasks(null));
        }

        private void MenuEditItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageTasks((Tasks)dtgTasks.SelectedItem));
        }

        private void MenuUpdateItem_Click(object sender, RoutedEventArgs e)
        {
            dtgTasks.ItemsSource = ProjectBDEntities.GetContext().Tasks.ToList();
            txtCountRows.Text = dtgTasks.Items.Count.ToString();
        }

        private void MenuDelItem_Click(object sender, RoutedEventArgs e)
        {
            var rowsForRemoving = dtgTasks.SelectedItems.Cast<Tasks>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {rowsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ProjectBDEntities.GetContext().Tasks.RemoveRange(rowsForRemoving);
                    ProjectBDEntities.GetContext().SaveChanges();
                    dtgTasks.ItemsSource = ProjectBDEntities.GetContext().Tasks.ToList();
                    txtCountRows.Text = dtgTasks.Items.Count.ToString();
                    MessageBox.Show("Данные удалены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }
        private void MenuSortASC_Click(object sender, RoutedEventArgs e)
        {
            dtgTasks.ItemsSource = ProjectBDEntities.GetContext().Tasks.OrderBy(x => x.Title).ToList();
            txtCountRows.Text = dtgTasks.Items.Count.ToString();
        }

        private void MenuSortDESC_Click(object sender, RoutedEventArgs e)
        {
            dtgTasks.ItemsSource = ProjectBDEntities.GetContext().Tasks.OrderByDescending(x => x.Title).ToList();
            txtCountRows.Text = dtgTasks.Items.Count.ToString();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            dtgTasks.ItemsSource = ProjectBDEntities.GetContext().Tasks.ToList();
            txtCountRows.Text = dtgTasks.Items.Count.ToString();
        }
    }
}
