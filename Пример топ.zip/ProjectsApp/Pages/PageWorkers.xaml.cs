﻿using Microsoft.Office.Interop.Excel;
using ProjectsApp.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjectsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageWorkers.xaml
    /// </summary>
    public partial class PageWorkers : System.Windows.Controls.Page
    {
        public PageWorkers()
        {
            InitializeComponent();
            foreach (Workers w in ProjectBDEntities.GetContext().Workers.ToList()) w.FIO = w.Surname + " " + w.Name + " " + w.Patronymic;
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuSearch1_Click(object sender, RoutedEventArgs e)
        {
            if (SearchPanel.Visibility == Visibility.Hidden)
            {
                SearchMargin.Height = new GridLength(1.2, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                SearchMargin.Height = new GridLength(0, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void txbWor_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (lstvWorkers.ItemsSource != null) lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.Where(x => x.Name.ToLower().Contains(txbWor.Text.ToLower()) || x.Surname.ToLower().Contains(txbWor.Text.ToLower()) || x.Patronymic.ToLower().Contains(txbWor.Text.ToLower())).ToList();
            if (txbWor.Text.Count() == 0) lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }
        private void MenuAddItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageWorkers(null));
        }

        private void MenuEditItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPageWorkers((Workers)lstvWorkers.SelectedItem));
        }

        private void MenuUpdateItem_Click(object sender, RoutedEventArgs e)
        {
            foreach (Workers w in ProjectBDEntities.GetContext().Workers.ToList()) w.FIO = w.Surname + " " + w.Name + " " + w.Patronymic;
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuSortASC_Click(object sender, RoutedEventArgs e)
        {
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.OrderBy(x => x.Surname).ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuSortDESC_Click(object sender, RoutedEventArgs e)
        {
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.OrderByDescending(x => x.Surname).ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuFilter1_Click(object sender, RoutedEventArgs e)
        {
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.Where(x => x.Positions.Title == "Руководитель").ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuFilter2_Click(object sender, RoutedEventArgs e)
        {
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.Where(x => x.Positions.Title == "Проектировщик").ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuFilter3_Click(object sender, RoutedEventArgs e)
        {
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.Where(x => x.Positions.Title == "Веб-дизайнер").ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuFilter4_Click(object sender, RoutedEventArgs e)
        {
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.Where(x => x.Positions.Title == "Программист").ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuFilter5_Click(object sender, RoutedEventArgs e)
        {
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.Where(x => x.Positions.Title == "Тестировщик").ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }
        private void MenuFilter6_Click(object sender, RoutedEventArgs e)
        {
            lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.Where(x => x.Positions.Title == "Технический писатель").ToList();
            txtCountRows.Text = lstvWorkers.Items.Count.ToString();
        }

        private void MenuDelItem_Click(object sender, RoutedEventArgs e)
        {
            var rowForRemoving = (Workers)lstvWorkers.SelectedItem;
            if (MessageBox.Show($"Вы точно хотите удалить сотрудника {rowForRemoving.FIO}?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ProjectBDEntities.GetContext().Workers.Remove(rowForRemoving);
                    ProjectBDEntities.GetContext().SaveChanges();
                    lstvWorkers.ItemsSource = ProjectBDEntities.GetContext().Workers.ToList();
                    txtCountRows.Text = lstvWorkers.Items.Count.ToString();
                    MessageBox.Show("Данные удалены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
        }

        private void MenuPrint_Click(object sender, RoutedEventArgs e)
        {
            if (lstvWorkers.SelectedItem == null) MessageBox.Show("Выберите сотрудника!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            else
            {
                Workers _currentItem = (Workers)lstvWorkers.SelectedItem;

                var app = new Microsoft.Office.Interop.Excel.Application();
                Workbook wb = app.Workbooks.Add();
                Worksheet worksheet = app.Worksheets.Item[1];

                worksheet.Cells[1][1] = $"Сотрудник №{_currentItem.idWorker}";
                Range titleRange = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[6][1]];
                titleRange.Merge();
                titleRange.HorizontalAlignment = XlHAlign.xlHAlignCenter;
                titleRange.Font.Bold = true;
                titleRange.Font.Size = 20;

                worksheet.Cells[2][3] = "ФИО:";
                worksheet.Cells[2][3].HorizontalAlignment = XlHAlign.xlHAlignRight;
                worksheet.Cells[3][3] = _currentItem.FIO;
                worksheet.Cells[3][3].HorizontalAlignment = XlHAlign.xlHAlignLeft;
                Range custComRange = worksheet.Range[worksheet.Cells[3][3], worksheet.Cells[6][3]];
                custComRange.Merge();

                worksheet.Cells[2][5] = "Email:";
                worksheet.Cells[2][5].HorizontalAlignment = XlHAlign.xlHAlignRight;
                worksheet.Cells[3][5] = _currentItem.Email;
                worksheet.Cells[3][5].HorizontalAlignment = XlHAlign.xlHAlignLeft;
                Range projectRange = worksheet.Range[worksheet.Cells[3][5], worksheet.Cells[6][5]];
                projectRange.Merge();

                worksheet.Cells[2][7] = "Телефон:";
                worksheet.Cells[2][7].HorizontalAlignment = XlHAlign.xlHAlignRight;
                worksheet.Cells[3][7] = _currentItem.Phone;
                worksheet.Cells[3][7].HorizontalAlignment = XlHAlign.xlHAlignLeft;
                Range priorityRange = worksheet.Range[worksheet.Cells[3][7], worksheet.Cells[6][7]];
                priorityRange.Merge();

                worksheet.Cells[2][9] = "Должность:";
                worksheet.Cells[2][9].HorizontalAlignment = XlHAlign.xlHAlignRight;
                worksheet.Cells[3][9] = _currentItem.Positions.Title;
                worksheet.Cells[3][9].HorizontalAlignment = XlHAlign.xlHAlignLeft;
                Range dateStartRange = worksheet.Range[worksheet.Cells[3][9], worksheet.Cells[6][9]];
                dateStartRange.Merge();

                worksheet.Cells[1][12] = "Проекты сотрудника:";
                Range tableRange = worksheet.Range[worksheet.Cells[1][12], worksheet.Cells[6][12]];
                worksheet.Cells[1][12].HorizontalAlignment = XlHAlign.xlHAlignCenter;
                tableRange.Merge();
                tableRange.Font.Size = 14;

                int IndexRows = 13;
                worksheet.Cells[1][IndexRows] = "№";
                worksheet.Cells[2][IndexRows] = "Название компании заказчика";
                worksheet.Cells[3][IndexRows] = "Название проекта";
                worksheet.Cells[4][IndexRows] = "Приоритет выполнения";
                worksheet.Cells[5][IndexRows] = "Дата начала";
                worksheet.Cells[6][IndexRows] = "Дата окончания";
                Range headerRange = worksheet.Range[worksheet.Cells[1][IndexRows], worksheet.Cells[6][IndexRows]];
                headerRange.HorizontalAlignment = XlHAlign.xlHAlignCenter;
                headerRange.Font.Bold = true;
                headerRange.Borders.LineStyle = XlLineStyle.xlContinuous;
                headerRange.Borders.Weight = XlBorderWeight.xlThin;

                var printItems = from p in ProjectBDEntities.GetContext().Projects
                            join ptw in ProjectBDEntities.GetContext().PTW on p.idProject equals ptw.idProject
                            select new
                            {
                                NameCustCom = p.CustomerCompanies.Name,
                                NameProject = p.Title,
                                Priority = p.Priority,
                                DateStart = p.StartDate,
                                DateEnd = p.EndDate,
                                idWorker = ptw.idWorker
                            };
                foreach (var item in printItems.Where(x => x.idWorker == _currentItem.idWorker))
                {
                    worksheet.Cells[1][IndexRows + 1] = IndexRows - 12;
                    worksheet.Cells[1][IndexRows + 1].Font.Italic = true;
                    worksheet.Cells[1][IndexRows + 1].HorizontalAlignment = XlHAlign.xlHAlignCenter;
                    worksheet.Cells[1][IndexRows + 1].Borders.LineStyle = XlLineStyle.xlContinuous;
                    worksheet.Cells[1][IndexRows + 1].Borders.Weight = XlBorderWeight.xlThin;

                    worksheet.Cells[2][IndexRows + 1] = item.NameCustCom;
                    worksheet.Cells[3][IndexRows + 1] = item.NameProject;
                    worksheet.Cells[4][IndexRows + 1] = item.Priority;
                    worksheet.Cells[5][IndexRows + 1] = item.DateStart;
                    worksheet.Cells[6][IndexRows + 1] = item.DateEnd;
                    IndexRows++;

                    Range bodyRange = worksheet.Range[worksheet.Cells[2][IndexRows], worksheet.Cells[6][IndexRows]];
                    bodyRange.HorizontalAlignment = XlHAlign.xlHAlignLeft;
                    bodyRange.Borders.LineStyle = XlLineStyle.xlContinuous;
                    bodyRange.Borders.Weight = XlBorderWeight.xlThin;
                }

                worksheet.Name = _currentItem.FIO;
                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                worksheet.Columns[1].ColumnWidth = 5;
                app.Visible = true;
            }
        }
    }
    
}
